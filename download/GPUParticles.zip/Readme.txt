There are two scenes in this demo, which can be cycled through by pressing Space
The startup scene is farily simple, but the other one has over 1,000,000 particles and will slow down
if not run on a high end GPU.